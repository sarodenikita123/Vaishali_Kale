from django.db import models
from django.db import models


class Employee(models.Model):
    STATUS_CHOICES = [
        ('Onboarded', 'Onboarded'),
        ('Not Onboarded', 'Not Onboarded'),
    ]

    PROJECT_DOMAINS = [PROJECT_DOMAINS = [
        ('SAAS', 'SAAS'),
        ('Ecommerce', 'Ecommerce'),
        ('CRM', 'CRM'),
    ]

    name = models.CharField(max_length=100, null=False)
    company = models.CharField(max_length=50, null=False)
    email_id = models.EmailField(unique=True)
    department = models.CharField(max_length=50, null=False)
    date_of_joining = models.DateField()
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='Not Onboarded')
    project_domain = models.CharField(max_length=100)

    def __str__(self):
        return self.name


