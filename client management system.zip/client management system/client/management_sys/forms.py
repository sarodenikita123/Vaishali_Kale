from django import forms
from .models import Employee


class EmployeeForm(forms.ModelForm):
    project_domain = forms.MultipleChoiceField(
        choices=Employee.PROJECT_DOMAINS,
        widget=forms.CheckboxSelectMultiple
    )

    class Meta:
        model = Employee
        fields = ['name', 'company', 'email_id', 'department', 'date_of_joining', 'status', 'project_domain']

    def clean_project_domain(self):
        data = self.cleaned_data['project_domain']
        return ','.join(data)  # Store as comma-separated string


3.
Update
Views
In
clients / views.py, update
the
views
to
use
the
new
EmployeeForm and handle
multiple
selections
for project_domain:

python
Copy
code
from django.shortcuts import render, get_object_or_404, redirect
from .models import Employee
from .forms import EmployeeForm


def add_employee(request):
    if request.method == 'POST':
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('view_employees')
    else:
        form = EmployeeForm()
    return render(request, 'clients/add_employee.html', {'form': form})


def view_employees(request):
    employees = Employee.objects.all()
    return render(request, 'clients/view_employees.html', {'employees': employees})


def update_employee(request, pk):
    employee = get_object_or_404(Employee, pk=pk)
    if request.method == 'POST':
        form = EmployeeForm(request.POST, instance=employee)
        if form.is_valid():
            form.save()
            return redirect('view_employees')
    else:
        form = EmployeeForm(instance=employee)
    return render(request, 'clients/update_employee.html', {'form': form})


def delete_employee(request, pk):
    employee = get_object_or_404(Employee, pk=pk)
    if request.method == 'POST':
        employee.delete()
        return redirect('view_employees')
    return render(request, 'clients/delete_employee.html', {'employee': employee})


def search_employees(request):
    query = request.GET.get('q')
    employees = Employee.objects.filter(
        name__icontains=query
    ) | Employee.objects.filter(
        company__icontains=query
    ) | Employee.objects.filter(
        department__icontains=query
    )
    return render(request, 'clients/view_employees.html', {'employees': employees})


def filter_employees(request):
    status = request.GET.get('status')
    project_domain = request.GET.get('project_domain')
    employees = Employee.objects.all()
    if status:
        employees = employees.filter(status=status)
    if project_domain:
        employees = employees.filter(project_domain__icontains=project_domain)
    return render(request, 'clients/view_employees.html', {'employees': employees})


4.
Update
Templates
Create / update
the
necessary
HTML
templates(add_employee.html, view_employees.html, update_employee.html, delete_employee.html):

templates / clients / add_employee.html

html
Copy
code
< h2 > Add
New
Employee < / h2 >
< form
method = "post" >
{ % csrf_token %}
{{form.as_p}}
< button
type = "submit" > Save < / button >
< / form >
templates / clients / view_employees.html

html
Copy
code
< h2 > All
Employees < / h2 >
< form
method = "get"
action = "{% url 'search_employees' %}" >
< input
type = "text"
name = "q"
placeholder = "Search employees" >
< button
type = "submit" > Search < / button >
< / form >
< form
method = "get"
action = "{% url 'filter_employees' %}" >
< select
name = "status" >
< option
value = "" > All
Status < / option >
< option
value = "Onboarded" > Onboarded < / option >
< option
value = "Not Onboarded" > Not
Onboarded < / option >
< / select >
< select
name = "project_domain" >
< option
value = "" > All
Domains < / option >
< option
value = "SAAS" > SAAS < / option >
< option
value = "Ecommerce" > Ecommerce < / option >
< option
value = "CRM" > CRM < / option >
< !-- Add
more
domains as needed -->
< / select >
< button
type = "submit" > Filter < / button >
< / form >
< ul >
{ %
for employee in employees %}
< li >
{{employee.name}} - {{employee.company}} - {{employee.department}} - {{employee.date_of_joining}} - {
    {employee.status}} - {{employee.project_domain}}
< a
href = "{% url 'update_employee' employee.pk %}" > Edit < / a >
< a
href = "{% url 'delete_employee' employee.pk %}" > Delete < / a >
< / li >
{ % endfor %}
< / ul >
templates / clients / update_employee.html

html
Copy
code
< h2 > Edit
Employee < / h2 >
< form
method = "post" >
{ % csrf_token %}
{{form.as_p}}
< button
type = "submit" > Save < / button >
< / form >