from django.apps import AppConfig


class ManagementSysConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'management_sys'
