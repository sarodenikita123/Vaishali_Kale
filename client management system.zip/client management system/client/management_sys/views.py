from django.shortcuts import render

from django.shortcuts import render, get_object_or_404, redirect
from .models import Employee
from .forms import EmployeeForm

def add_employee(request):
    if request.method == 'POST':
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('view_employees')
    else:
        form = EmployeeForm()
        return render(request, 'clients/add_employee.html', {'form': form})

    def view_employees(request):
        employees = Employee.objects.all()
        return render(request, 'clients/view_employees.html', {'employees': employees})

    def update_employee(request, pk):
        employee = get_object_or_404(Employee, pk=pk)
        if request.method == 'POST':


